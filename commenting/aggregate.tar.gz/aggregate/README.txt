########################################################################

This is the data set used in the Master's thesis
  How Programmers Comment When They Think Nobody's Watching
by Simon Benjamin Orion Parent

The correct way to reference this data set is to cite this thesis,
for example with the BibTeX entry:

@mastersthesis{
  parent2014,
  title={\textit{How Programmers Comment
    When They Think Nobody's Watching}},
  author={Parent, Simon Benjamin Orion},
  year={2014},
  school={University of Waterloo},
}

Chapter 2 of the thesis contains important information about the
data set which is not repeated here.

A public web page for both the thesis and this data set,
with up-to-date contact information, can be found at:

http://www.cgl.uwaterloo.ca/~commenting/

########################################################################
### Description of Data Format

The data files are tab-separated with column names in the first row.
Note that some column names contain spaces.

The public version of this aggregate data has been censored:
* The columns 'filename', 'name', and 'corrected text' were removed.
* The lines of each file have been sorted.
The uncensored data set can be requested at:

http://www.cgl.uwaterloo.ca/~commenting/

########################################################################
### files.dat

### name
The filename, which always has the format
  (group)/(milestone)/src/...
In many cases redundant directory structure in their submissions
has been collapsed.

### group
An identifier for the group of programmers, which consists of a
letter followed by an arbitrarily assigned two-digit number.
### milestone
Indicates for which assignment this file was submitted.
Consists of the letter 'k' (for operating system kernel)
or 'p' (for train project), followed by a number.
The milestones are, in order: k1 k2 k3 k4 p1 p2 p3.
### codebase
Just (group)/(milestone).

### basictype
The basic file type, always one of:
  assembly
  header
  implementation
  script
### filetype
A more detailed filetype, of the form
  (basictype)/(additional info).

### difficulty
For the A-series implementation files in milestone p3, this is
the task category as defined in the thesis.

### length
The number of lines of code in the file.
### nonblank
The number of nonblank lines of code in the file.
### commented
The number of lines of code in the file containing part of a comment.
### commented nonblank
The number of lines of code in the file containing part of a comment
which are also nonblank.
### commented legit
The number of lines of code in the file containing part of a comment
which is not marked as being one of: a compiler-generated comment,
part of provided code, or commented-out code.
Only meaningful for the A-series data.

### density
The proportion of commented lines in the file.
### D2A
The proportion of commented lines in the first half of the file.
### D2B
The proportion of commented lines in the second half of the file.
### D3A, ..., D5E
D(n)(k) is similarly the proportion of commented lines in the
kth (where A=1 and so on) nth of the file.

### future changed
For a file in k4 with a matching file in p3,
this is 1 if there were any changes to the file, and 0 otherwise.
### future density
The 'density' column value of that file, if it exists.
### future length
The 'length' column value of that file, if it exists.
### future commented
The 'commented' column value of that file, if it exists.

########################################################################
### comments.dat

### filename
The name of the file in which the comment occurs.

### group, milestone, codebase, basictype, filetype
Same as for files.dat; inherited from the file.

### manually cleaved
1 if this comment was affected by the manual splitting and merging
or comments, and 0 otherwise.
Only meaningful for the A-series data.

### indicator
The indicator symbol for the comment, e.g. slash-slash (//).

### num lines
The number of lines spanned by the comment.
### one line
1 if the comment is one line, and 0 otherwise.

### is redacted
1 if the comment has any redacted text, and 0 otherwise.

### raw length
The number of characters in the literal comment text.

### left column
The column in which the literal comment text begins.
(starting at 1, and the tab width is assumed to be 8)

### corrected text
The corrected text of the comment as defined in the thesis.
### corrected length
The number of characters in the corrected comment text.
### words
The number of words in the corrected comment text.

### source m
The source of the comment (was it written by a human, or generated
by a compiler, or from provided code, or commented-out code)
as determined by heuristics.
### source h
The source of the comment as determined by a human.
Only meaningful for the A-series data.
### source
Equal to 'source h' if it is present, otherwise 'source m'.

### category
The comment category as determined by manual inspection.
Only meaningful for the A-series data.
### subcategory
The comment subcategory, of the form (category)/(subcategory).
Only meaningful for the A-series data.
### category full
The raw comment subcategory as originally entered,
of the form (category)/(subcategory).
Some of these were merged together and renamed for 'subcategory'.
Only meaningful for the A-series data.
